README for "transcript2pe" v1.0. Copyright (c) Peter J P Croucher 2013

Copyrighted under the Artist License 2.0
Version 1.0. 27 August 2013.
Email: pete@petercroucher.com


"transcript2pe" is a Python program (tested under Python 2.7.3) that takes as input a 
multi-fasta (.fa) format file containing a transcriptome assembly (for example as output
by Trinity [1]). The assembled transcripts are then converted into 'dummy' paired end 
fastq (.fq) Illumina style files, using a sliding-window algorithm, that may be used for 
genome scaffolding (for example).

The input fasta file should be of the following format:

>comp30_c0_seq1 len=229 path=[77:0-228]
GCTAGTAATTAATGATTTATGCTTTTTAAAAATTGAAAATATGAATATTTTATTTTGTGT
CAATATTATAATTGTTTTTCTAAAATATTGAAATAAATAAGCATAGTTTTGTACAAATGT
TAATTTATGGCTTTTATATATACTTGTATTTGCTCAAGACTATATATTTGTTAATTATTT
CAGTACAAAAATATAATTTTTTTAAACTCTACTAGAGGGTTCTGCCCAC
>comp58_c0_seq1 len=204 path=[229:0-77 126:78-203]
TTGGCAATCAGATGAAATATTCTGGTACCTTCAAGGCGTCTAAATTTTCCGTTCAAATTT
TGAGCACTACCTTATTTCTTTAATTCTGAGGAAATGTGAATGATGAACAATTATTTACTA
TTCTACAAATTACTGTCATTTTTCTGAAAGTAAGCAGGTAGTTAATGACTATTCATAATG
AGAATCAAGTGTGCAGGTTTAAAA

The length variable information (the second item in each header e.g., len=229) is 
important as it is recognized by the program. A test example is included.

The output (.fq) format is as follows:

@DUMMYPELIB:1:1:1:1#0/1
TGAGGAGTGACTTAGGTGCAAAAAAGGCGTTCTTTCGTCGGCGGAAAGCC
+DUMMYPELIB:1:1:1:1#0/1
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
@DUMMYPELIB:1:1:2:2#0/1
TGTTAATCCGCCAGGTATAATGGCTATATCGGCGGAGAGCTTCTTGCATC
+DUMMYPELIB:1:1:2:2#0/1
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
@DUMMYPELIB:1:1:3:3#0/1
TAATCGTGATTCAATACTTTCAATAGTATATGTGATCGTAAATTATCAAG
+DUMMYPELIB:1:1:3:3#0/1
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII

There are two such output files - forward reads (suffix "_1") and reverse reads 
(suffix "_2"). The pairs in each file are synchronized. Dummy quality values are created
as the letter code I, corresponding Illumina 1.3+ Phred+64 score 40.


Installation:
The program consists of two files, the main program module (transcript2pe_main.py) and a
simply script that calls that module (transcript2pe.py). Simply place these files in the 
working directory (or in a directory that is on your path if desired). Make sure 
transcript2pe.py is executable.

Dependencies:
Python 2.7.3 - though other versions probably work. No other dependencies or special 
modules are required. 

Algorithm:
We presuppose that assembled transcripts (de novo) represent a relatively high-quality
and 'clean' dataset (compared to the raw RNA-seq reads) from which we can mine 'dummy' 
paired end read data for use in scaffolding a de novo genome assembly. We cannot know a
true insert size because the length of any untranscribed introns is unknown. Actual 
"insert sizes" will typically be determined by mapping steps during the scaffolding
process and "reads" crossing intron/exon boundaries will typically fail to map.
By generating a large number of "reads" and apportioning these into "libraries" based upon
the length of the intervening transcript sequence we hope to generate scaffolding 
libraries with reasonable size distributions.

The algorithm proceeds simply, taking each transcript in turn, and if it's length exceeds
a specified number of base pairs (which must be the minimum "gap" to be maintained between
the reads plus twice the "read length") then it is sliced into a set of paired end reads.
First, the reverse read is fixed as a specified number of bases ("read length") in from 
the end of the transcript. The first forward read is then generated starting from the 
first base in until the "read length" is reached. Subsequent forward reads are then 
generated in turn (the reverse read remains fixed as above), starting from a specified 
number of bases 3' (the "jump") in a sliding-window manner until the end of a forward read  
would reduce the "gap" length between the forward and reverse read to less than the 
specified minimum. The process is then repeated, fixing the outermost forward read and 
generating corresponding reverse reads. The program does not currently generate read pairs 
for all forward and reverse combinations. 

Once all transcripts have been parsed, the reads pairs are sorted by length (dummy reads
plus the intervening sequence gap - based on the transcript contig, not the genome) and 
are binned into a specified number of "libraries" with approximately equal numbers of read
pairs per library. For each library, a histogram frequency table of lengths may be output.

Usage and Options:

To run the program from the current directory:

./transcript2pe.py [options] <.fasta file>

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -g GAP, --gap=GAP     Enter a minimum gap length to maintain between PE
                        (DEFAULT: 50)
  -m MIN, --min=MIN     Enter a minimum length contig to consider (DEFAULT:
                        150)
  -r READ, --read=READ  Enter a 'read' length (DEFAULT: 50)
  -j JUMP, --jump=JUMP  Enter number of bases to jump between taking 'reads'
                        (DEFAULT: 5)
  -l LIBNO, --lib=LIBNO
                        Enter number of libraries to construct (DEFAULT: 10)
  -w WRITE, --write=WRITE
                        Write new PE libraries to file (big files); if 'N'
                        just writes info to screen [Verbose must be on!]
                        (DEFAULT: 'Y')
  -v VERBOSE, --verbose=VERBOSE
                        Print progress to screen? (Y/N) (DEFAULT: 'Y')
  -d HISTOGRAM, --dist=HISTOGRAM
                        Generate a histogram of 'fragment' sizes for each
                        library (Y/N) (DEFAULT: 'Y')
  -b BIN, --bin=BIN     Select histogram bin size (bp) (DEFAULT: 50)

NB: Output files will be appended not over-written; to avoid this delete or move old output 
files from this script!

---

[1] Grabherr MG, Haas BJ, Yassour M, Levin JZ, Thompson DA, Amit I, Adiconis X, 
    Fan L, Raychowdhury R, Zeng Q, Chen Z, Mauceli E, Hacohen N, Gnirke A, Rhind N, 
    di Palma F, Birren BW, Nusbaum C, Lindblad-Toh K, Friedman N, Regev A. 
    Full-length transcriptome assembly from RNA-seq data without a reference genome. 
    Nat Biotechnol. 2011 May 15;29(7):644-52. doi: 10.1038/nbt.1883. 
    PubMed PMID: 21572440. 