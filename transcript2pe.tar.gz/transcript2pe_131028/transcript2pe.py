#! /usr/bin/env python

### transcript2pe ###
###: a script to convert a transcriptome sequence file ### 
### (.fa) to multiple 'dummy' PE libraries (.fastq) that may be useful ###
### for genome scaffolding ###

### transcript2pe v1.0. Copyright (c) Peter J P Croucher 2013###
### Copyrighted under the Artist License 2.0 ###

###Email: pete@petercroucher.com

###Version 1.0. 27 August 2013.

###A simple bootstrap script to initialize transcript2pe:

import transcript2pe_main

transcript2pe_main.Main()

###END


