#! /usr/bin/env python

### transcript2pe ###
###: a script to convert a transcriptome sequence file ### 
### (.fa) to multiple 'dummy' PE libraries (.fastq) that may be useful ###
### for genome scaffolding ###

### transcript2pe v1.0. Copyright (c) Peter J P Croucher 2013###
### Copyrighted under the Artist License 2.0 ###

###Email: pete@petercroucher.com

###Version 1.0. 27 August 2013.


#Input file should be of the following format (e.g. "Trinity" style) with "len=\d+" as
#the second item

# >comp30_c0_seq1 len=229 path=[77:0-228]
# GCTAGTAATTAATGATTTATGCTTTTTAAAAATTGAAAATATGAATATTTTATTTTGTGT
# CAATATTATAATTGTTTTTCTAAAATATTGAAATAAATAAGCATAGTTTTGTACAAATGT
# TAATTTATGGCTTTTATATATACTTGTATTTGCTCAAGACTATATATTTGTTAATTATTT
# CAGTACAAAAATATAATTTTTTTAAACTCTACTAGAGGGTTCTGCCCAC
# >comp58_c0_seq1 len=204 path=[229:0-77 126:78-203]
# TTGGCAATCAGATGAAATATTCTGGTACCTTCAAGGCGTCTAAATTTTCCGTTCAAATTT
# TGAGCACTACCTTATTTCTTTAATTCTGAGGAAATGTGAATGATGAACAATTATTTACTA
# TTCTACAAATTACTGTCATTTTTCTGAAAGTAAGCAGGTAGTTAATGACTATTCATAATG
# AGAATCAAGTGTGCAGGTTTAAAA


from optparse import *
import re
import math
import sys


class Main(object):

    """
    """
    
    
    def __init__(self): 
        
        self.pe_dict = {}
        self.total_readpairs = 0

        self.main()

    #####################################
    ### Get options from command line ###
    #####################################

    ###Print out program details at start of run!
    
    def main(self):
        """Gets and stores the file names from the command line
        and generates help messages"""

        print "\n--- transcript2pe v1.0. Peter J P Croucher 2013---\n"
        
        usage = "%prog [options] <.fasta file> (for help type: %prog -h)"
        parser = OptionParser(usage=usage, version = "%prog 1.0")
        parser.add_option("-g","--gap", action="store", dest="gap", type="int", help="Enter a minimum gap length to maintain between PE (DEFAULT: 50)")
        parser.add_option("-m","--min", action="store", dest="min", type="int", help="Enter a minimum length contig to consider (DEFAULT: 150)")
        parser.add_option("-r","--read", action="store", dest="read", type="int", help="Enter a 'read' length (DEFAULT: 50)")
        parser.add_option("-j","--jump", action="store", dest="jump", type="int", help="Enter number of bases to jump between taking 'reads' (DEFAULT: 5)")
        parser.add_option("-l","--lib", action="store", dest="libno", type="int", help="Enter number of libraries to construct (DEFAULT: 10)")
        parser.add_option("-w","--write", action="store", dest="write", type="str", help="Write new PE libraries to file (big files); if 'N' just writes info to screen [Verbose must be on!] (DEFAULT: 'Y')")
        parser.add_option("-v","--verbose", action="store", dest="verbose", type="str", help="Print progress to screen? (Y/N) (DEFAULT: 'Y')")
        parser.add_option("-d","--dist", action="store", dest="histogram", type="str", help="Generate a histogram of 'fragment' sizes for each library (Y/N) (DEFAULT: 'Y')")
        parser.add_option("-b","--bin", action="store", dest="bin", type="float", help="Select histogram bin size (bp) (DEFAULT: 50)")
        
        parser.set_defaults(gap=50, min=150, read=50, jump=5, libno=10, write='Y', verbose='Y', histogram='Y', bin=50)
        (self.options, self.args) = parser.parse_args()

        ###Apply sanity checks!
        if self.options.min < self.options.gap + (2* self.options.read):
            raise ValueError, "Minimum contig length must be greater than gap length plus twice the read length!"
        
        
        self.parse_fasta()
        self.analyse_pairs()
        if self.options.histogram == 'Y': self.histogram()
        if self.options.write == 'N':
            print "\nNew PE pairs NOT being written to files!!\n"
        else:
            print "\nNew PE pairs being written to files!!\n"
        
        self.write_data()
        
        
    def parse_fasta(self):
        
        self.header_re = re.compile('^>(.*)\s+len=(\d+).*')
        
        no_of_contigs = 0
        no_of_contigs_of_min_length = 0
        new_reads = {}
        length = 0
        mergedata = []
        if self.options.verbose == 'Y': print "Parsing contig file and generating PE reads..."
        for line in file(self.args[0]):
            if self.header_re.match(line): 
                #print line
                no_of_contigs += 1
                if length >= self.options.min:
                    no_of_contigs_of_min_length += 1
                    self.get_reads_forward(length, mergedata)
                    self.get_reads_reverse(length, mergedata)
                length = 0
                mergedata = []
                #print line
                length = int(self.header_re.match(line).group(2))
            else:
                data = list(line.strip())
                [mergedata.append(x) for x in data]

        #final time:
        if length >= self.options.min:
            self.get_reads_forward(length, mergedata)
            self.get_reads_reverse(length, mergedata)
        
        if self.options.verbose == 'Y': 
            print "\nDone parsing contig file and generating PE reads"
            print "\nTotal number of contigs read: ", no_of_contigs
            print "\nTotal number of contigs meeting minimum length requirement: ", no_of_contigs_of_min_length
        
        return None
    
    

    def get_reads_forward(self,length,mergedata): 
        
        index = 0
        reverse = mergedata[-self.options.read:]
        reverse = self.get_revcomp(reverse)
        reverse = ''.join(reverse)
        #print reverse
        
        while index+self.options.read < len(mergedata)-(self.options.read+self.options.gap):
            forward = mergedata[index:index+self.options.read]
            forward = ''.join(forward)
            #print forward
            length = len(mergedata)-index
            #print length
            index += self.options.jump
            
            if self.pe_dict.has_key(length):
                self.pe_dict[length].append((forward, reverse))
            else:
                self.pe_dict[length] = [(forward, reverse)]
    
        return None


    def get_reads_reverse(self,length,mergedata):
        
        index = self.options.jump
        forward = mergedata[:self.options.read]
        forward = ''.join(forward)
        #print forward
        #print mergedata
        
        while len(mergedata)-(index+self.options.read) > self.options.read+self.options.gap:
            reverse = mergedata[-(index+self.options.read):-index]
            reverse = self.get_revcomp(reverse)
            reverse = ''.join(reverse)
            #print reverse
            length = len(mergedata)-index
            #print length
            index += self.options.jump
            
            if self.pe_dict.has_key(length):
                self.pe_dict[length].append((forward, reverse))
            else:
                self.pe_dict[length] = [(forward, reverse)]
    
        return None



    def get_revcomp(self,reverse):
    
        reverse.reverse()
        indices = xrange(len(reverse))
        for i in indices:
            if reverse[i] == 'A': reverse[i] = 'T'
            elif reverse[i] == 'a': reverse[i] = 't'
            elif reverse[i] == 'C': reverse[i] = 'G'
            elif reverse[i] == 'c': reverse[i] = 'g'
            elif reverse[i] == 'G': reverse[i] = 'C'
            elif reverse[i] == 'g': reverse[i] = 'c'
            elif reverse[i] == 'T': reverse[i] = 'A'
            elif reverse[i] == 't': reverse[i] = 'a'
            else: pass
    
        return reverse


    def analyse_pairs(self):
    
        if self.options.verbose == 'Y': print "\nCounting PE reads..."
        for length in self.pe_dict:
            no_pairs = len(self.pe_dict[length])
            self.total_readpairs += no_pairs
            self.pe_dict[length].insert(0,no_pairs)
            
        if self.options.verbose == 'Y': print "\nNumber of readpairs: ",self.total_readpairs
        keys = self.pe_dict.keys()
        keys.sort()

        #We need to sort the read_pairs by length and divide the count by the number of libraries wanted
        no_pairs_per_lib = self.total_readpairs/(self.options.libno) 
       
        #print no_pairs_per_lib

        if self.options.verbose == 'Y': print "\nTarget number PE reads per library:", no_pairs_per_lib

        libraries = xrange(1,self.options.libno+1)
        
        self.multi_pe_dicts = {}
        for lib in libraries:
            self.multi_pe_dicts[lib] = []
        
        for lib in libraries:
            no_pairs = 0
            current_keys = []
            if lib != self.options.libno:
                for key in keys:
                    if self.pe_dict[key][0] + no_pairs < no_pairs_per_lib:
                        no_pairs += self.pe_dict[key][0]
                        self.multi_pe_dicts[lib].append(key)
                        current_keys.append(key)
                    else:
                        self.multi_pe_dicts[lib].insert(0,0) #this will be used for mean length - if histogram chosen 
                        self.multi_pe_dicts[lib].insert(1,no_pairs)
                        break
                for key in current_keys:
                    keys.remove(key)
            else:
                for key in keys:
                    no_pairs += self.pe_dict[key][0]
                    self.multi_pe_dicts[lib].append(key)
                    #current_keys.append(key)
                self.multi_pe_dicts[lib].insert(0,0) #this will be used for mean length - if histogram chosen 
                self.multi_pe_dicts[lib].insert(1,no_pairs)
                            
        return None



    def histogram(self): #Also calculates library stats - just mean!
    
        for lib in self.multi_pe_dicts:
            total_length = 0
            bins = {}
            #print "\n"
            #print lib, self.multi_pe_dicts[lib]
            #get appropriate number of bins from maximum length fragment divided by bin size
            #Bins start at zero so that libraries can be easily compared...may change this
            no_bins = int(math.ceil(self.multi_pe_dicts[lib][-1]/float(self.options.bin))+1)
            #print "No. of bins",no_bins
        
            ##to bin the data we will just make a dictionary with keys corresponding to the bin number
            for x in xrange(1,no_bins+1):
                bins[x] = 0
                #print "X",x
            
            for length in self.multi_pe_dicts[lib][2:]:
             #   print length, self.pe_dict[length][0]
                bin = divmod(length,self.options.bin)[0]+1
              #  print bin
                bins[bin] += self.pe_dict[length][0]
                total_length += length*self.pe_dict[length][0]
            
            #for bin in bins:
                #print "BIN", bin, bins[bin]
            #print total_length
            mean_length = total_length/float(self.multi_pe_dicts[lib][1])
            self.multi_pe_dicts[lib][0] += round(mean_length,2)
            
            self.write_histograms(lib,bins)
        

    
        return None


    def write_histograms(self,lib,bins):
    
        RESULTS = open(sys.argv[1]+"_dummy_PE_lib"+str(lib)+".hist",mode="a")
        RESULTS.write("Library no: "+str(lib)+"\nNo. of readpairs: "+str(self.multi_pe_dicts[lib][1])+"\nMean length: "+str(self.multi_pe_dicts[lib][0])+"\n")
        keys = bins.keys()
        keys.sort()
        for key in keys:
            bin1 = (key-1)*int(self.options.bin)
            bin2 = bin1+int(self.options.bin-1)
            bin12 = str(bin1)+":"+str(bin2)
            #print bin12
            RESULTS.write(bin12+"\t"+str(bins[key])+"\n")
        
        RESULTS.close()
        
        return None



    def write_data(self): #Need to make fastq!!! (Check) and for number of libs!
        
        if self.options.verbose == 'Y':
            for item in self.multi_pe_dicts:
                if self.options.histogram == 'Y':
                    print "Library no: ",item, "No. of readpairs: ", self.multi_pe_dicts[item][1], "Mean length: ", self.multi_pe_dicts[item][0]
                else:
                    print "Library no: ",item, "No. of readpairs: ", self.multi_pe_dicts[item][1]
                    
        if self.options.write == 'Y':
            for lib in self.multi_pe_dicts:
                dummy_no = 0
                RESULTS1 = open(sys.argv[1]+"_dummy_PE_lib"+str(lib)+"_1.fq",mode="a")
                RESULTS2 = open(sys.argv[1]+"_dummy_PE_lib"+str(lib)+"_2.fq",mode="a")
                for length in self.multi_pe_dicts[lib][2:]:
                    #print "Lengths: ",length,
                    for pair in self.pe_dict[length][1:]:
                        dummy_no += 1
                        RESULTS1.write("@DUMMYPELIB:1:1:"+str(dummy_no)+":"+str(dummy_no)+"#0/1\n"+pair[0]+"\n")
                        RESULTS1.write("+DUMMYPELIB:1:1:"+str(dummy_no)+":"+str(dummy_no)+"#0/1\n"+"I"*self.options.read+"\n")
                        RESULTS2.write("@DUMMYPELIB:1:1:"+str(dummy_no)+":"+str(dummy_no)+"#0/2\n"+pair[1]+"\n")
                        RESULTS2.write("+DUMMYPELIB:1:1:"+str(dummy_no)+":"+str(dummy_no)+"#0/2\n"+"I"*self.options.read+"\n")
                        
                RESULTS1.close()
                RESULTS2.close()

        print "\nDONE!\n"
        
        return None

